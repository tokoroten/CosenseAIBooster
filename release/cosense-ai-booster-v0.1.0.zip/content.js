/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./src/utils/cosense-dom.ts":
/*!**********************************!*\
  !*** ./src/utils/cosense-dom.ts ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CosenseDOMUtils: () => (/* binding */ CosenseDOMUtils)
/* harmony export */ });
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
/**
 * Cosense (Scrapbox) のDOM操作を行うユーティリティクラス
 */
class CosenseDOMUtils {
    /**
     * Cosenseのページが読み込まれているかどうかを判定
     */
    static isCosensePage() {
        return window.location.hostname === 'scrapbox.io';
    }
    /**
     * 現在のプロジェクト名を取得
     */
    static getProjectName() {
        const pathParts = window.location.pathname.split('/').filter(Boolean);
        return pathParts.length > 0 ? pathParts[0] : null;
    }
    /**
     * 現在のページ名を取得
     */
    static getPageName() {
        const pathParts = window.location.pathname.split('/').filter(Boolean);
        return pathParts.length > 1 ? pathParts[1] : null;
    }
    /**
     * 選択されたテキストを取得
     */
    static getSelectedText() {
        const selection = window.getSelection();
        return selection ? selection.toString() : '';
    }
    /**
     * テキストをCosenseページに挿入する
     * 選択範囲の下または最下部に挿入
     */
    static insertText(text, insertPosition) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                if (insertPosition === 'bottom') {
                    // 最下部に挿入する場合
                    return yield this.insertTextAtBottom(text);
                }
                else {
                    // 選択範囲の下に挿入する場合
                    return yield this.insertTextBelowSelection(text);
                }
            }
            catch (error) {
                console.error('Failed to insert text:', error);
                return false;
            }
        });
    }
    /**
     * ページの最下部にテキストを挿入
     * Cosenseのエディタインタフェースを利用してテキストを挿入
     */
    static insertTextAtBottom(text) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                // 最下部の行を見つける
                const linesContainer = document.querySelector('.lines');
                if (!linesContainer)
                    return false;
                // エディタが利用可能かチェック
                const editor = this.getEditor();
                if (editor) {
                    // エディタを使ってテキストを挿入する
                    return this.insertTextUsingEditor(editor, text, 'bottom');
                }
                // エディタが見つからない場合は従来のDOMベースの方法を試みる
                const lastLine = linesContainer.querySelector('.line:last-child');
                if (lastLine) {
                    // 最後の行にフォーカス
                    this.simulateClick(lastLine);
                    // 操作後に少し待つ
                    yield this.wait(200);
                    // 最後の行の末尾にカーソルを移動
                    const lastLineDiv = lastLine.querySelector('div');
                    if (lastLineDiv) {
                        const range = document.createRange();
                        const selection = window.getSelection();
                        range.selectNodeContents(lastLineDiv);
                        range.collapse(false); // カーソルを末尾に移動
                        if (selection) {
                            selection.removeAllRanges();
                            selection.addRange(range);
                        }
                        // エンターキーを押して新しい行を作成
                        yield this.simulateEnterKey();
                        // 操作後に少し待つ
                        yield this.wait(200);
                        // テキストを挿入
                        document.execCommand('insertText', false, text);
                        return true;
                    }
                }
                return false;
            }
            catch (error) {
                console.error('Error inserting text at bottom:', error);
                return false;
            }
        });
    }
    /**
     * 選択範囲の下にテキストを挿入
     * Cosenseのエディタインタフェースを利用してテキストを挿入
     */
    static insertTextBelowSelection(text) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const selection = window.getSelection();
                if (!selection || selection.rangeCount === 0)
                    return false;
                const range = selection.getRangeAt(0);
                const lineElement = this.findLineElement(range.endContainer);
                // エディタが利用可能かチェック
                const editor = this.getEditor();
                if (editor && lineElement) {
                    // エディタを使ってテキストを挿入する
                    return this.insertTextUsingEditor(editor, text, 'below', lineElement);
                }
                if (lineElement) {
                    // 選択範囲の行をクリック
                    this.simulateClick(lineElement);
                    // 操作後に少し待つ
                    yield this.wait(200);
                    // 選択範囲の行の末尾にカーソルを移動
                    const lineDiv = lineElement.querySelector('div');
                    if (lineDiv) {
                        const newRange = document.createRange();
                        newRange.selectNodeContents(lineDiv);
                        newRange.collapse(false); // カーソルを末尾に移動
                        selection.removeAllRanges();
                        selection.addRange(newRange);
                    }
                    // エンターキーを押して新しい行を作成
                    yield this.simulateEnterKey();
                    // 操作後に少し待つ
                    yield this.wait(200);
                    // テキストを挿入
                    document.execCommand('insertText', false, text);
                    return true;
                }
                return false;
            }
            catch (error) {
                console.error('Error inserting text below selection:', error);
                return false;
            }
        });
    }
    /**
     * エディターがある場合はそれを取得する
     */
    static getEditor() {
        // Cosenseのエディタ要素を探す
        const editor = document.querySelector('.editor');
        return editor;
    }
    /**
     * エディターを使用してテキストを挿入する
     */
    static insertTextUsingEditor(editor, text, position, targetLine) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                // 位置に応じたカーソル設定
                if (position === 'bottom') {
                    // 最後の行にカーソルを移動
                    const lines = editor.querySelectorAll('.line');
                    if (lines.length > 0) {
                        const lastLine = lines[lines.length - 1];
                        this.simulateClick(lastLine);
                    }
                }
                else if (targetLine) {
                    // 対象の行にカーソルを移動
                    this.simulateClick(targetLine);
                }
                else {
                    return false;
                }
                // 操作後に少し待つ
                yield this.wait(200);
                // エンターキーを押して新しい行を作成
                yield this.simulateEnterKey();
                // 操作後に少し待つ
                yield this.wait(200);
                // テキストを挿入
                const lines = text.split('\n');
                for (let i = 0; i < lines.length; i++) {
                    document.execCommand('insertText', false, lines[i]);
                    if (i < lines.length - 1) {
                        yield this.simulateEnterKey();
                        yield this.wait(100);
                    }
                }
                return true;
            }
            catch (error) {
                console.error('Error inserting text using editor:', error);
                return false;
            }
        });
    }
    /**
     * クリックイベントをシミュレート
     */
    static simulateClick(element) {
        element.dispatchEvent(new MouseEvent('click', {
            bubbles: true,
            cancelable: true,
            view: window,
        }));
    }
    /**
     * Enterキーのイベントをシミュレートする
     */
    static simulateEnterKey() {
        return __awaiter(this, void 0, void 0, function* () {
            var _a;
            const enterEvent = new KeyboardEvent('keydown', {
                key: 'Enter',
                code: 'Enter',
                keyCode: 13,
                which: 13,
                bubbles: true,
                cancelable: true,
            });
            (_a = document.activeElement) === null || _a === void 0 ? void 0 : _a.dispatchEvent(enterEvent);
        });
    }
    /**
     * 指定したミリ秒だけ待機する
     */
    static wait(ms) {
        return new Promise((resolve) => setTimeout(resolve, ms));
    }
    /**
     * 行要素を見つける
     */
    static findLineElement(element) {
        let current = element;
        while (current && current.nodeType !== Node.ELEMENT_NODE) {
            current = current.parentNode;
        }
        if (!current)
            return null;
        let currentElement = current;
        while (currentElement && !currentElement.classList.contains('line')) {
            if (!currentElement.parentElement)
                return null;
            currentElement = currentElement.parentElement;
        }
        return currentElement;
    }
    /**
     * 右サイドバーにアイコンを追加
     */
    static addIconToSidebar(iconHTML, iconClass, onClick) {
        try {
            const toolsContainer = document.querySelector('.tools');
            if (!toolsContainer)
                return null;
            const iconWrapper = document.createElement('div');
            iconWrapper.className = `tool-icon ${iconClass}`;
            iconWrapper.innerHTML = iconHTML;
            iconWrapper.addEventListener('click', onClick);
            toolsContainer.appendChild(iconWrapper);
            return iconWrapper;
        }
        catch (error) {
            console.error('Error adding icon to sidebar:', error);
            return null;
        }
    }
}


/***/ }),

/***/ "./src/utils/speech-recognition.ts":
/*!*****************************************!*\
  !*** ./src/utils/speech-recognition.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SpeechRecognitionService: () => (/* binding */ SpeechRecognitionService)
/* harmony export */ });
class SpeechRecognitionService {
    constructor(options) {
        this.isListening = false;
        this.finalTranscript = '';
        this.interimTranscript = '';
        this.recognitionTimeout = null;
        this.pauseDetected = false;
        this.lastResultTimestamp = 0;
        this._onEndCallback = null;
        // WebSpeech API の非標準な型のため、any を使用
        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        if (!SpeechRecognition) {
            throw new Error('Speech Recognition is not supported in this browser.');
        }
        this.recognition = new SpeechRecognition();
        this.recognition.lang = (options === null || options === void 0 ? void 0 : options.language) || 'ja-JP';
        this.recognition.continuous = (options === null || options === void 0 ? void 0 : options.continuous) !== undefined ? options.continuous : true;
        this.recognition.interimResults =
            (options === null || options === void 0 ? void 0 : options.interimResults) !== undefined ? options.interimResults : true;
        // Set up automatic restart for longer sessions
        this.recognition.onend = this.onRecognitionEnd.bind(this);
    }
    /**
     * 音声認識の開始
     */
    start() {
        if (this.isListening)
            return;
        this.finalTranscript = '';
        this.interimTranscript = '';
        this.isListening = true;
        this.pauseDetected = false;
        this.lastResultTimestamp = Date.now();
        try {
            this.recognition.start();
            // Set up pause detection
            this.startPauseDetection();
        }
        catch (error) {
            this.isListening = false;
            throw error;
        }
    }
    /**
     * 音声認識の停止
     */
    stop() {
        if (!this.isListening)
            return this.finalTranscript;
        this.isListening = false;
        this.clearPauseDetection();
        try {
            this.recognition.stop();
        }
        catch (error) {
            // Handle the error silently
        }
        return this.finalTranscript;
    }
    /**
     * 音声認識の一時停止
     */
    pause() {
        if (!this.isListening)
            return false;
        try {
            this.pauseDetected = true;
            this.recognition.stop();
            return true;
        }
        catch (error) {
            return false;
        }
    }
    /**
     * 音声認識の再開
     */
    resume() {
        if (!this.pauseDetected)
            return false;
        try {
            this.pauseDetected = false;
            this.recognition.start();
            this.startPauseDetection();
            return true;
        }
        catch (error) {
            return false;
        }
    }
    /**
     * 認識結果のハンドリング
     */
    onResult(callback) {
        this.recognition.onresult = (event) => {
            var _a;
            this.interimTranscript = '';
            this.lastResultTimestamp = Date.now();
            for (let i = event.resultIndex; i < event.results.length; ++i) {
                if (event.results[i].isFinal) {
                    this.finalTranscript += event.results[i][0].transcript;
                }
                else {
                    this.interimTranscript += event.results[i][0].transcript;
                }
            }
            const isFinal = !!((_a = event.results[event.results.length - 1]) === null || _a === void 0 ? void 0 : _a.isFinal);
            callback(this.finalTranscript, this.interimTranscript, isFinal);
            // 結果が確定したら一時停止検出タイマーをリセット
            if (isFinal) {
                this.resetPauseDetection();
            }
        };
    }
    /**
     * 音声認識終了時のハンドラ設定
     */
    onEnd(callback) {
        this._onEndCallback = callback;
    }
    /**
     * エラー発生時のハンドラ設定
     */
    onError(callback) {
        this.recognition.onerror = (event) => {
            this.isListening = false;
            callback(event);
        };
    }
    /**
     * 言語設定の変更
     */
    setLanguage(language) {
        this.recognition.lang = language;
        // 認識中の場合は再起動して新しい言語設定を適用
        if (this.isListening) {
            const wasListening = this.isListening;
            this.stop();
            if (wasListening) {
                setTimeout(() => this.start(), 300);
            }
        }
    }
    /**
     * トランスクリプトのクリア
     */
    clearTranscript() {
        this.finalTranscript = '';
        this.interimTranscript = '';
    }
    /**
     * 音声認識がサポートされているかどうか
     */
    isSupported() {
        return !!window.SpeechRecognition || !!window.webkitSpeechRecognition;
    }
    /**
     * 音声認識のステータス取得
     */
    getStatus() {
        return {
            isListening: this.isListening,
            isPaused: this.pauseDetected,
            finalText: this.finalTranscript,
            interimText: this.interimTranscript,
        };
    }
    /**
     * 音声認識終了時の内部ハンドラ
     */
    onRecognitionEnd() {
        // 手動で停止した場合や一時停止の場合は何もしない
        if (!this.isListening || this.pauseDetected) {
            if (this._onEndCallback)
                this._onEndCallback();
            return;
        }
        // 自動的に終了した場合は再起動する
        // (5秒の制限などでブラウザが停止させた場合)
        setTimeout(() => {
            if (this.isListening) {
                try {
                    this.recognition.start();
                }
                catch (error) {
                    this.isListening = false;
                    if (this._onEndCallback)
                        this._onEndCallback();
                }
            }
        }, 300);
    }
    /**
     * 一時停止検出の開始
     * 一定時間発話がない場合に一時停止とみなす
     */
    startPauseDetection() {
        this.clearPauseDetection();
        this.recognitionTimeout = window.setTimeout(() => {
            const timeSinceLastResult = Date.now() - this.lastResultTimestamp;
            if (timeSinceLastResult > 1500 && this.isListening) {
                // 1.5秒間発話がなければ自動的に一時停止
                this.pause();
            }
        }, 2000);
    }
    /**
     * 一時停止検出タイマーのクリア
     */
    clearPauseDetection() {
        if (this.recognitionTimeout) {
            clearTimeout(this.recognitionTimeout);
            this.recognitionTimeout = null;
        }
    }
    /**
     * 一時停止検出タイマーのリセット
     */
    resetPauseDetection() {
        this.clearPauseDetection();
        if (this.isListening && !this.pauseDetected) {
            this.startPauseDetection();
        }
    }
}


/***/ }),

/***/ "./src/utils/storage.ts":
/*!******************************!*\
  !*** ./src/utils/storage.ts ***!
  \******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   StorageService: () => (/* binding */ StorageService)
/* harmony export */ });
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
class StorageService {
    /**
     * 設定を初期化
     */
    static initializeSettings() {
        return __awaiter(this, void 0, void 0, function* () {
            const defaultSettings = {
                prompts: [
                    {
                        id: this.generateId(),
                        name: '要約',
                        content: '以下のテキストを要約してください:\n\n{{text}}',
                        model: 'gpt-3.5-turbo',
                    },
                    {
                        id: this.generateId(),
                        name: '翻訳（日本語→英語）',
                        content: '以下のテキストを英語に翻訳してください:\n\n{{text}}',
                        model: 'gpt-3.5-turbo',
                    },
                ],
                insertPosition: 'below',
                speechLang: 'ja-JP',
                apiProvider: 'openai',
                openaiKey: '',
                openaiModel: 'gpt-3.5-turbo',
                openrouterKey: '',
                openrouterModel: 'openai/gpt-3.5-turbo',
                customEndpoint: '',
                customKey: '',
                customModel: '',
            };
            const settings = yield this.getSettings();
            if (!settings) {
                yield this.saveSettings(defaultSettings);
                return defaultSettings;
            }
            return settings;
        });
    }
    /**
     * 設定を保存
     */
    static saveSettings(settings) {
        return __awaiter(this, void 0, void 0, function* () {
            return new Promise((resolve, reject) => {
                chrome.storage.sync.set(settings, () => {
                    if (chrome.runtime.lastError) {
                        reject(chrome.runtime.lastError);
                    }
                    else {
                        resolve();
                    }
                });
            });
        });
    } /**
     * 設定を取得
     */
    static getSettings() {
        return __awaiter(this, void 0, void 0, function* () {
            return new Promise((resolve) => {
                try {
                    chrome.storage.sync.get(null, (items) => {
                        if (chrome.runtime.lastError) {
                            // eslint-disable-next-line no-console
                            console.error('Storage error:', chrome.runtime.lastError);
                            resolve(null);
                        }
                        else {
                            // 最低限必要なプロパティを持っていない場合は初期設定を返す
                            if (!items || typeof items !== 'object' || !('prompts' in items)) {
                                // eslint-disable-next-line no-console
                                console.warn('Invalid settings, initializing defaults');
                                this.initializeSettings().then((defaultSettings) => resolve(defaultSettings));
                            }
                            else {
                                resolve(items);
                            }
                        }
                    });
                }
                catch (error) {
                    // eslint-disable-next-line no-console
                    console.error('Error getting settings:', error);
                    resolve(null);
                }
            });
        });
    }
    /**
     * プロンプトを追加・更新
     */
    static savePrompt(prompt) {
        return __awaiter(this, void 0, void 0, function* () {
            const settings = yield this.getSettings();
            if (!settings)
                throw new Error('Settings not found');
            const prompts = settings.prompts || [];
            const newPrompt = {
                id: prompt.id || this.generateId(),
                name: prompt.name,
                content: prompt.content,
                model: prompt.model,
            };
            const existingPromptIndex = prompts.findIndex((p) => p.id === prompt.id);
            if (existingPromptIndex >= 0) {
                prompts[existingPromptIndex] = newPrompt;
            }
            else {
                prompts.push(newPrompt);
            }
            yield this.saveSettings(Object.assign(Object.assign({}, settings), { prompts }));
            return newPrompt;
        });
    }
    /**
     * プロンプトを削除
     */
    static deletePrompt(id) {
        return __awaiter(this, void 0, void 0, function* () {
            const settings = yield this.getSettings();
            if (!settings)
                throw new Error('Settings not found');
            const prompts = settings.prompts || [];
            const promptIndex = prompts.findIndex((p) => p.id === id);
            if (promptIndex >= 0) {
                prompts.splice(promptIndex, 1);
                yield this.saveSettings(Object.assign(Object.assign({}, settings), { prompts }));
            }
        });
    }
    /**
     * ランダムIDの生成
     */
    static generateId() {
        return (Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15));
    }
}


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry needs to be wrapped in an IIFE because it needs to be isolated against other modules in the chunk.
(() => {
/*!******************************!*\
  !*** ./src/content/index.ts ***!
  \******************************/
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _utils_speech_recognition__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../utils/speech-recognition */ "./src/utils/speech-recognition.ts");
/* harmony import */ var _utils_cosense_dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../utils/cosense-dom */ "./src/utils/cosense-dom.ts");
/* harmony import */ var _utils_storage__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../utils/storage */ "./src/utils/storage.ts");
/**
 * Content script for Cosense AI Booster
 */



// 状態管理
let speechRecognition = null;
let isSpeechListening = false;
let micIcon = null;
const processingPromptIds = new Set();
// アイコンSVG
const MIC_SVG = `<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
  <path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"></path>
  <path d="M19 10v2a7 7 0 0 1-14 0v-2"></path>
  <line x1="12" y1="19" x2="12" y2="23"></line>
  <line x1="8" y1="23" x2="16" y2="23"></line>
</svg>`;
const MIC_ACTIVE_SVG = `<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#ff4081" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
  <path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"></path>
  <path d="M19 10v2a7 7 0 0 1-14 0v-2"></path>
  <line x1="12" y1="19" x2="12" y2="23"></line>
  <line x1="8" y1="23" x2="16" y2="23"></line>
</svg>`;
const SETTINGS_SVG = `<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
  <circle cx="12" cy="12" r="3"></circle>
  <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path>
</svg>`;
// CSS スタイル
const STYLE = `
.cosense-ai-icon {
  cursor: pointer;
  padding: 6px;
  border-radius: 4px;
  margin: 4px 0;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #666;
  transition: all 0.2s;
}
.cosense-ai-icon:hover {
  background-color: rgba(0, 0, 0, 0.05);
  color: #333;
}
.cosense-ai-icon.active {
  color: #ff4081;
}
.cosense-ai-status {
  position: fixed;
  bottom: 20px;
  right: 20px;
  background-color: rgba(255, 255, 255, 0.9);
  border-radius: 8px;
  padding: 12px 16px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  z-index: 10000;
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 14px;
  transition: opacity 0.3s;
}
.cosense-ai-status.hidden {
  opacity: 0;
  pointer-events: none;
}
.cosense-ai-status .status-icon {
  display: flex;
}
.cosense-ai-status .status-icon.loading {
  animation: spin 1.5s linear infinite;
}
@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}
`;
// 初期化
(function init() {
    if (!_utils_cosense_dom__WEBPACK_IMPORTED_MODULE_1__.CosenseDOMUtils.isCosensePage())
        return;
    // DOMが読み込まれたら初期化処理
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', onDOMContentLoaded);
    }
    else {
        onDOMContentLoaded();
    }
})();
/**
 * DOMコンテンツ読み込み完了時の処理
 */
function onDOMContentLoaded() {
    // スタイルの追加
    addStyles();
    // UIの初期化
    initializeUI();
    // 音声認識の初期化
    initializeSpeechRecognition();
    // メッセージリスナーの設定
    setupMessageListeners();
}
/**
 * スタイルの追加
 */
function addStyles() {
    const styleElement = document.createElement('style');
    styleElement.textContent = STYLE;
    document.head.appendChild(styleElement);
}
/**
 * UIの初期化
 */
function initializeUI() {
    // マイクアイコンとスタイル追加
    micIcon = _utils_cosense_dom__WEBPACK_IMPORTED_MODULE_1__.CosenseDOMUtils.addIconToSidebar(MIC_SVG, 'cosense-ai-icon cosense-ai-mic', toggleSpeechRecognition);
    // 設定アイコンとスタイル追加
    _utils_cosense_dom__WEBPACK_IMPORTED_MODULE_1__.CosenseDOMUtils.addIconToSidebar(SETTINGS_SVG, 'cosense-ai-icon cosense-ai-settings', openSettings);
}
/**
 * 音声認識の初期化
 */
function initializeSpeechRecognition() {
    try {
        // 設定を読み込む
        _utils_storage__WEBPACK_IMPORTED_MODULE_2__.StorageService.getSettings().then((settings) => {
            if (!settings)
                return;
            speechRecognition = new _utils_speech_recognition__WEBPACK_IMPORTED_MODULE_0__.SpeechRecognitionService({
                language: settings.speechLang,
                continuous: true,
                interimResults: true,
            });
            // 結果ハンドラ
            speechRecognition.onResult((final, interim, isFinal) => {
                // 中間結果の場合はステータス表示を更新
                if (!isFinal) {
                    if (interim) {
                        const statusElement = document.querySelector('.cosense-ai-status');
                        if (statusElement) {
                            const messageDiv = statusElement.querySelector('div:last-child');
                            if (messageDiv) {
                                messageDiv.textContent = `音声認識中: ${interim}`;
                            }
                        }
                    }
                    return;
                }
                // 確定した音声テキストをページに挿入
                const text = final.trim();
                if (text) {
                    // 設定で指定された挿入位置に挿入
                    _utils_storage__WEBPACK_IMPORTED_MODULE_2__.StorageService.getSettings().then((settings) => {
                        const insertPosition = (settings === null || settings === void 0 ? void 0 : settings.insertPosition) || 'bottom';
                        _utils_cosense_dom__WEBPACK_IMPORTED_MODULE_1__.CosenseDOMUtils.insertText(text, insertPosition).then((success) => {
                            if (!success) {
                                showStatus('テキスト挿入に失敗しました', 'error');
                            }
                        });
                    });
                }
            });
            // 終了ハンドラ
            speechRecognition.onEnd(() => {
                if (isSpeechListening) {
                    // 自動的に終了した場合（一時停止検出など）
                    const status = speechRecognition === null || speechRecognition === void 0 ? void 0 : speechRecognition.getStatus();
                    if (status === null || status === void 0 ? void 0 : status.isPaused) {
                        // 一時停止の場合
                        showStatus('一時停止中（話すと再開します）', 'normal');
                        // 10秒後に何も話さなければ完全に停止
                        setTimeout(() => {
                            const currentStatus = speechRecognition === null || speechRecognition === void 0 ? void 0 : speechRecognition.getStatus();
                            if (currentStatus === null || currentStatus === void 0 ? void 0 : currentStatus.isPaused) {
                                speechRecognition === null || speechRecognition === void 0 ? void 0 : speechRecognition.stop();
                                isSpeechListening = false;
                                updateMicIcon();
                                showStatus('音声認識を停止しました');
                            }
                        }, 10000);
                    }
                    else {
                        isSpeechListening = false;
                        updateMicIcon();
                    }
                }
            });
            // エラーハンドラ
            speechRecognition.onError((event) => {
                isSpeechListening = false;
                updateMicIcon();
                // エラーの種類によって異なるメッセージを表示
                let errorMessage = '音声認識エラー';
                if ((event === null || event === void 0 ? void 0 : event.error) === 'not-allowed') {
                    errorMessage = 'マイクの使用が許可されていません';
                }
                else if ((event === null || event === void 0 ? void 0 : event.error) === 'no-speech') {
                    errorMessage = '音声が検出されませんでした';
                }
                showStatus(errorMessage, 'error');
            });
        });
    }
    catch (error) {
        showStatus('音声認識機能が利用できません', 'error');
    }
}
/**
 * 音声認識の切り替え
 */
function toggleSpeechRecognition() {
    if (!speechRecognition) {
        showStatus('音声認識機能が利用できません', 'error');
        return;
    }
    const status = speechRecognition.getStatus();
    if (isSpeechListening) {
        if (status.isPaused) {
            // 一時停止中の場合は再開
            try {
                speechRecognition.resume();
                showStatus('音声認識を再開しました', 'listening');
            }
            catch (error) {
                showStatus('音声認識を再開できませんでした', 'error');
            }
        }
        else {
            // 動作中の場合は停止
            speechRecognition.stop();
            isSpeechListening = false;
            showStatus('音声認識を停止しました');
        }
    }
    else {
        // 停止中の場合は開始
        try {
            speechRecognition.start();
            isSpeechListening = true;
            showStatus('音声認識中...', 'listening');
        }
        catch (error) {
            isSpeechListening = false;
            showStatus('音声認識を開始できませんでした', 'error');
        }
    }
    updateMicIcon();
}
/**
 * マイクアイコンの状態を更新
 */
function updateMicIcon() {
    if (!micIcon)
        return;
    if (isSpeechListening) {
        micIcon.innerHTML = MIC_ACTIVE_SVG;
        micIcon.classList.add('active');
    }
    else {
        micIcon.innerHTML = MIC_SVG;
        micIcon.classList.remove('active');
    }
}
/**
 * 設定画面を開く
 */
function openSettings() {
    chrome.runtime.sendMessage({ action: 'openOptionsPage' });
}
/**
 * ステータス表示
 */
function showStatus(message, type = 'normal') {
    // 既存のステータス要素を削除
    const existingStatus = document.querySelector('.cosense-ai-status');
    if (existingStatus) {
        existingStatus.remove();
    }
    // 新しいステータス要素を作成
    const statusElement = document.createElement('div');
    statusElement.className = 'cosense-ai-status';
    let icon = '';
    switch (type) {
        case 'error':
            icon = `<div class="status-icon error"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#f44336" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="15" y1="9" x2="9" y2="15"></line><line x1="9" y1="9" x2="15" y2="15"></line></svg></div>`;
            break;
        case 'listening':
            icon = `<div class="status-icon listening"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#4caf50" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"></path><path d="M19 10v2a7 7 0 0 1-14 0v-2"></path><line x1="12" y1="19" x2="12" y2="23"></line><line x1="8" y1="23" x2="16" y2="23"></line></svg></div>`;
            break;
        case 'loading':
            icon = `<div class="status-icon loading"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#2196f3" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a9 9 0 1 1-6.219-8.56"></path></svg></div>`;
            break;
        default:
            icon = `<div class="status-icon"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#2196f3" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg></div>`;
    }
    statusElement.innerHTML = `${icon}<div>${message}</div>`;
    document.body.appendChild(statusElement);
    // 3秒後に消す（エラーとロード中は除く）
    if (type !== 'error' && type !== 'loading') {
        setTimeout(() => {
            statusElement.classList.add('hidden');
            setTimeout(() => statusElement.remove(), 300);
        }, 3000);
    }
    return statusElement;
}
/**
 * プロンプト処理中のステータスを表示
 */
function showProcessingStatus(promptId) {
    processingPromptIds.add(promptId);
    const statusElement = showStatus('AIによる処理中...', 'loading');
    if (!(statusElement instanceof HTMLElement)) {
        return document.createElement('div'); // fallback
    }
    return statusElement;
}
/**
 * プロンプト処理終了時のステータスを更新
 */
function hideProcessingStatus(promptId, success = true) {
    processingPromptIds.delete(promptId);
    // すでにステータス表示がなければ何もしない
    const statusElement = document.querySelector('.cosense-ai-status');
    if (!statusElement)
        return;
    // 他のプロンプトがまだ処理中なら表示を維持
    if (processingPromptIds.size > 0)
        return;
    // ステータス表示を消す
    statusElement.classList.add('hidden');
    setTimeout(() => statusElement.remove(), 300);
    // 成功メッセージを一瞬表示
    if (success) {
        showStatus('処理が完了しました');
    }
}
/**
 * メッセージリスナーの設定
 */
function setupMessageListeners() {
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
        switch (message.action) {
            case 'startProcessingPrompt':
                handleStartProcessingPrompt(message.data);
                break;
            case 'insertProcessedText':
                handleInsertProcessedText(message.data);
                break;
            case 'showError':
                handleShowError(message.data);
                break;
        }
        sendResponse({ success: true });
        return false;
    });
}
/**
 * プロンプト処理開始時の処理
 */
function handleStartProcessingPrompt(data) {
    const { promptId } = data;
    showProcessingStatus(promptId);
}
/**
 * 処理結果挿入の処理
 */
function handleInsertProcessedText(data) {
    const { text, promptId, insertPosition } = data;
    // テキストを挿入
    _utils_cosense_dom__WEBPACK_IMPORTED_MODULE_1__.CosenseDOMUtils.insertText(text, insertPosition)
        .then(() => {
        hideProcessingStatus(promptId, true);
    })
        .catch(() => {
        hideProcessingStatus(promptId, false);
        showStatus('テキスト挿入に失敗しました', 'error');
    });
}
/**
 * エラー表示の処理
 */
function handleShowError(data) {
    const { message, promptId } = data;
    hideProcessingStatus(promptId, false);
    showStatus(`エラー: ${message}`, 'error');
}

})();

/******/ })()
;
//# sourceMappingURL=content.js.map