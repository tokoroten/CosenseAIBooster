/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/*!****************************!*\
  !*** ./src/popup/index.ts ***!
  \****************************/

/**
 * Popup script for Cosense AI Booster
 */
document.addEventListener('DOMContentLoaded', () => {
    // 設定ボタンにイベントリスナーを追加
    const openOptionsButton = document.getElementById('open-options');
    if (openOptionsButton) {
        openOptionsButton.addEventListener('click', openOptions);
    }
    // 現在のタブがCosenseページかどうかをチェック
    checkCurrentTab();
});
/**
 * 設定ページを開く
 */
function openOptions() {
    chrome.runtime.openOptionsPage();
}
/**
 * 現在のタブがCosenseページかどうかをチェック
 */
function checkCurrentTab() {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        const currentTab = tabs[0];
        const statusMessage = document.getElementById('status-message');
        if (statusMessage) {
            if (currentTab.url && currentTab.url.includes('scrapbox.io')) {
                statusMessage.textContent = 'Cosenseページで動作中';
                statusMessage.className = 'text-sm text-green-600 mb-3';
            }
            else {
                statusMessage.textContent = 'Cosenseページでのみ機能します';
                statusMessage.className = 'text-sm text-red-600 mb-3';
            }
        }
    });
}

/******/ })()
;
//# sourceMappingURL=popup.js.map